<footer class="footer border-top">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-4">
				<div class="copyright">All Rights Reserved | &copy; <?php echo SITE_NAME ?> - <?php echo date('Y') ?></div>
			</div>
			<div class="col">
				<div class="footer-links text-right">
					<a href="https://www.putraritoyan.top/">Tentang</a> | 
					<a href="https://www.youtube.com/c/PUTRARITOYAN">Bantuan</a> |
				
				</div>
			</div>
			
		</div>
	</div>
</footer>